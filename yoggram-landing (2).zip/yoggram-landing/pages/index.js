import { motion } from 'framer-motion'
import { Leaf, CalendarCheck, Heart } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center p-6">
      <div className="max-w-3xl w-full bg-white shadow-xl rounded-2xl overflow-hidden p-8 text-center space-y-6">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-3xl font-bold text-green-800"
        >
          🌿 Patanjali Yog Gram – Natural Healing Retreat
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-gray-600 text-lg"
        >
          Experience Yoga, Ayurveda & Naturopathy at Haridwar. Book your wellness journey today.
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          <motion.div whileHover={{ scale: 1.05 }} className="p-4 bg-green-100 rounded-xl shadow">
            <Leaf className="mx-auto text-green-700 mb-2" size={36} />
            <p className="font-semibold text-green-800">Ayurvedic Therapies</p>
          </motion.div>

          <motion.div whileHover={{ scale: 1.05 }} className="p-4 bg-green-100 rounded-xl shadow">
            <Heart className="mx-auto text-green-700 mb-2" size={36} />
            <p className="font-semibold text-green-800">Holistic Healing</p>
          </motion.div>

          <motion.div whileHover={{ scale: 1.05 }} className="p-4 bg-green-100 rounded-xl shadow">
            <CalendarCheck className="mx-auto text-green-700 mb-2" size={36} />
            <p className="font-semibold text-green-800">Easy Online Booking</p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
        >
          <a href="https://yoggram.divyayoga.com" target="_blank" rel="noopener noreferrer">
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-2xl text-lg">
              Book Your Stay
            </button>
          </a>
        </motion.div>

        <p className="text-sm text-gray-500 mt-4">
          Limited slots available. Visit{' '}
          <a href="https://yoggram.divyayoga.com" target="_blank" className="text-green-700 underline">yoggram.divyayoga.com</a>{' '}
          to confirm your booking.
        </p>
      </div>
    </div>
  )
}
